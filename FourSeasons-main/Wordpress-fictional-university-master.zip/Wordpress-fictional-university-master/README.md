# Wordpress-fictional-university
Project files from LearnWebCode's free WordPress course

After working up to this point using Atom remotely and uploading code examples online, I have now installed GitHub Desktop to simplify the process and speed things up. 
